package com.example.grouptoggletestingapp;

import com.msi.moble.ApplicationParameters;
import com.msi.moble.MotorolaApplicationCallback;
import com.msi.moble.mobleAddress;

/**
 * The type Default app callback.
 */
public class defaultAppCallback implements MotorolaApplicationCallback {

    @Override
    public void onWriteLocalData(mobleAddress mobleAddress, mobleAddress mobleAddress1, Object o, short i, byte b, byte[] bytes) {

    }

    @Override
    public void onUpdateRemoteData(mobleAddress peer, Object cookies, short offset, byte count, byte[] data) {
    }



    @Override
    public void onResponse(mobleAddress peer, Object cookies, byte status, byte[] data) {
    }

    @Override
    public void onDongleStateChanged(boolean enabled) {
    }

    @Override
    public void onBufferLoadChanged(int count) {
    }

    @Override
    public void onProxyConnectionEvent(boolean process, String proxyAddress) {
    }

    public void onModelPublicationStatus(boolean b, ApplicationParameters.Status status, ApplicationParameters.Address address, ApplicationParameters.Address address1, ApplicationParameters.KeyIndex keyIndex, ApplicationParameters.TTL ttl, ApplicationParameters.Time time, ApplicationParameters.GenericModelID genericModelID) {

    }

    @Override
    public void onDeviceAppeared(String bt_addr) {
    }

    @Override
    public void onError(String text) {
    }

    @Override
    public void onDeviceRssiChanged(String s, int i) {

    }

    @Override
    public void inRange(boolean b, boolean b1) {

    }

    @Override
    public void modelCallback(ApplicationParameters.Address address, ApplicationParameters.Address address1) {

    }

    @Override
    public void onHeartBeatRecievedCallback(ApplicationParameters.Address address, ApplicationParameters.TTL ttl, ApplicationParameters.Features features) {

    }
}
