package com.example.grouptoggletestingapp;

import com.msi.moble.DataMap.Base;

/**
 * This is Set of Application Commands to be sent to the Nodes.
 */
public final class Nucleo extends Base {


    public final static byte APPLI_CMD_UNPROVISION= 0;

    public final static byte APPLI_CMD_TEST_RSVD = 1;
    public final static byte APPLI_CMD_TEST_RSVD_TEST_RESET_PARAMS = 1;
    public final static byte APPLI_CMD_TEST_RSVD_TEST_ECHO = 2;
    public final static byte APPLI_CMD_TEST_RSVD_TEST_RANDMZD_RESP = 3;
    public final static byte APPLI_CMD_TEST_RSVD_TEST_COUNTER = 4;
    public final static byte APPLI_CMD_TEST_RSVD_TEST_INC_COUNTER = 5;


    public final static byte APPLI_CMD_DEVICE = 2;
    public final static byte APPLI_CMD_DEVICE_IC_TYPE = 1;
    public final static byte APPLI_CMD_DEVICE_BMESH_LIBVER_SUB = 3;
    public final static byte APPLI_CMD_DEVICE_BMESH_LIBVER = 2;
    public final static byte APPLI_CMD_DEVICE_BMESH_APPVER = 4;



    public final static byte APPLI_CMD_LED_CONTROL = 3;
    public final static byte APPLI_CMD_LED_ON = 1;
    public final static byte APPLI_CMD_LED_OFF = 2;
    public final static byte APPLI_CMD_LED_TOGGLE = 3;
    public final static byte APPLI_CMD_LED_BULB = 5;


    public final static byte APPLI_CMD_DEVICE_TYPE = 4;


    public final static byte APPLI_CMD_SENSORS = 5;
    public final static byte APPLI_CMD_TEMPERATURE = 1;
    public final static byte APPLI_CMD_SENSORS_PRESSURE = 2;
    public final static byte APPLI_CMD_SENSORS_ACCEL = 3;



}

