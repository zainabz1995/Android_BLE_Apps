package com.example.grouptoggletestingapp;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.Gravity;
import android.view.WindowManager;

public class AppDialogLoader {
    private static AppDialogLoader loader = null;
    private static AppDialogLoader previousFragmentLoader = null;
    private static Context con;
    private ProgressDialog pDialog;

    public AppDialogLoader(Context context) {
        pDialog = new ProgressDialog(context, R.style.ProgressDialogTheme);
        pDialog.setProgressStyle(android.R.style.Widget_ProgressBar_Large);

        /*if (context.getClass().getName().equalsIgnoreCase((new AddGroupActivity()).getClass().getName())) {
            pDialog.setCancelable(false);
        } else {
            pDialog.setCancelable(false);
        }
*/
        pDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialog) {
                /****cleanup code****/
                dismiss();
            }
        });
    }

    //for leg product
    public AppDialogLoader(Context context, int progressDialogTheme) {
        pDialog = new ProgressDialog(context);
        pDialog.getWindow().setGravity(Gravity.CENTER_VERTICAL | Gravity.CENTER_HORIZONTAL);
        pDialog.getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
        pDialog.setMessage("Loading...");
        pDialog.setCancelable(true);

    }

    static AppDialogLoader getLoader(Context context) {
        con = context;

        {
            loader = new AppDialogLoader(context);
            previousFragmentLoader = loader;
        }

        return loader;
    }

    public static AppDialogLoader getLoader(Context context, int progressDialogTheme) {
        con = context;
        {
            loader = new AppDialogLoader(context, progressDialogTheme);
            previousFragmentLoader = loader;
        }

        return loader;
    }

    public boolean CheckLoaderStatus() {

        if (pDialog.isShowing() || previousFragmentLoader != null) {
            return true;
        } else {
            return false;
        }
    }

    private int count = 0;
    void show() {

        //Utils.DEBUG("AppDialogLoader >> show() : " + pDialog + " Countp >> : " + count);
        count++;

        //Utils.DEBUG("AppDialogLoader >> show() : " + pDialog);

        /*if(pDialog.isShowing())
        {
            pDialog.dismiss();
            pDialog.hide();
        }*/

        if(!pDialog.isShowing() && !((Activity) con).isFinishing())//use this condition to check, for any reason if the activity is destroyed then it will prevent from crash
        {
            pDialog.show();
        }

        /*if(con!=null) {
            if (con.getClass().getName().equalsIgnoreCase(AddGroupActivity.class.getName())) {
                if (!pDialog.isShowing() && !((AddGroupActivity) con).isFinishing())//use this condition to check, for any reason if the activity is destroyed then it will prevent from crash
                {
                    try {
                        pDialog.show();
                    } catch (Exception e) {
                    }
                }
            } else if (con.getClass().getName().equalsIgnoreCase(MainActivity.class.getName())) {
                if (!pDialog.isShowing() && !((MainActivity) con).isFinishing())//use this condition to check, for any reason if the activity is destroyed then it will prevent from crash
                {
                    try {
                        pDialog.show();
                    } catch (Exception e) {
                    }
                }
            }
        }*/


    }

    private void dismiss() {
        //Utils.DEBUG("AppDialogLoader >> dismiss() > " + pDialog);
        if (pDialog.isShowing()) {
            pDialog.dismiss();
        }
    }

    void hide() {
        //Utils.DEBUG("AppDialogLoader >> hide() > " + pDialog);
        if (pDialog.isShowing()) {
            pDialog.hide();
        }
    }

}
