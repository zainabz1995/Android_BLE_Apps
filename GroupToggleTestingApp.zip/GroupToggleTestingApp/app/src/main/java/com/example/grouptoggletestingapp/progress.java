package com.example.grouptoggletestingapp;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;

public class progress {
    private ProgressDialog mDialog;
    private static Context mContext;
    private onEventListener mListener;
    private int countAttempts = 0;
    /**
     * The Start time.
     */
    private long startTime;
    //public static final long PROGRESS_MIN_DELAY = 1000;

    /**
     * The interface On event listener.
     */
    public interface onEventListener {
        /**
         * On show.
         */
        void onShow();

        /**
         * On hide.
         */
        void onHide();

        /**
         * On cancel.
         */
        void onCancel();
    }

    /**
     * Instantiates a new Progress.
     *
     * @param context  the context
     * @param listener the listener
     */
    progress(Context context, onEventListener listener) {
        mContext = context;
        mDialog = null;
        mListener = listener;
    }


    /**
     * Show.
     *
     * @param enable_progress the enable progress
     */
    public void show(Context context, boolean enable_progress) {
        String mMessage = "Please wait...";
        show(context, mMessage, enable_progress);
    }

    /**
     * Show.
     *
     * @param text            the text
     * @param enable_progress the enable progress
     */
    public void show(Context mContext, String text, boolean enable_progress) {
        countAttempts++;
        if(countAttempts==1) {
            if (mListener != null) mListener.onShow();
            startTime = System.currentTimeMillis();
            mDialog = new ProgressDialog(mContext);
            mDialog.setCanceledOnTouchOutside(false);
            if(enable_progress) {
                mDialog.setMessage(text);
                mDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
                mDialog.setMax(10);
                mDialog.setIndeterminate(false);
                mDialog.setProgress(0);
            } else {
                mDialog.setIndeterminate(true);
                mDialog.setMessage(text);
            }
            mDialog.setOnCancelListener(new CancelListener(mListener));
            mDialog.show();
        }
    }

    /**
     * The type Cancel listener.
     */
    public static class CancelListener implements DialogInterface.OnCancelListener {
        private onEventListener mEventListener;

        /**
         * Instantiates a new Cancel listener.
         *
         * @param event the event
         */
        CancelListener(onEventListener event) {
            mEventListener = event;
        }

        @Override
        public void onCancel(DialogInterface dialogInterface) {
            if (mEventListener != null) mEventListener.onCancel();
            mEventListener = null;
        }
    }

    /*void setProgress(int progress) {
        if (mDialog == null) return;
        mDialog.setProgress(progress);
    } */

    /**
     * Sets progress.
     *
     * @param progress the progress
     * @param message  the message
     */
    void setProgress(int progress, String message) {
        if (mDialog == null) return;
        mDialog.setProgress(progress);
        if(message != null) {
            mDialog.setMessage(message);
        }
    }

    /**
     * Hide.
     */
    void hide() {
        if (mDialog == null) return;
        countAttempts--;
        if(countAttempts==0) {
            mDialog.setOnCancelListener(null);
            mDialog.dismiss();
            mDialog = null;
            startTime = -1;
            if (mListener != null) mListener.onHide();
        }
    }


}
