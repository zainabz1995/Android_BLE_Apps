package com.example.grouptoggletestingapp;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;
import com.msi.moble.ApplicationParameters;
import com.msi.moble.ConfigurationModelClient;
import com.msi.moble.CustomProvisioning;
import com.msi.moble.Device;
import com.msi.moble.DeviceCollection;
import com.msi.moble.mobleAddress;
import com.msi.moble.mobleNetwork;
import com.msi.moble.mobleProvisioningStatus;
import com.msi.moble.mobleSettings;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

public class MainActivity extends AppCompatActivity {

    TextView Status, Count;

    private static final String TAG_TEST = "TESTING";
    mobleAddress androidAddress = mobleAddress.deviceAddress(1);
    private static mobleNetwork mNetwork;
    private IntentIntegrator qrScan;
    private boolean is_group_test_running;
    private mobleSettings mSettings;

    long provisioning_start_time;
    int DEVICE_ADDRESS = 7;
    private mobleAddress nodeAddress;
    ArrayList<mobleAddress> node_address_arr = new ArrayList<>();
    private int elementSize;
    private AppDialogLoader loader;
    private boolean isAdvised = false;
    public boolean startRSSIUpdate = false;
    private boolean isNear = false;
    public boolean notPressed = false;
    public boolean PressedStop = false;
    int count = 0;
    private Switch vendor_generic_switch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button start = findViewById(R.id.start);
        Status = findViewById(R.id.textView);
        Count = findViewById(R.id.count);
        vendor_generic_switch = findViewById(R.id.vendor_generic_switch);
        qrScan = new IntentIntegrator(this);
        loader = AppDialogLoader.getLoader(this);

        vendor_generic_switch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean vendorModelSelection) {
                System.out.println("value of vendorModelSelection "+vendorModelSelection);
                Utils.setVendorModelCommand(MainActivity.this, vendorModelSelection);
            }
        });

        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                notPressed = true;
                startNetwork();
            }
        });

        Button Stop = findViewById(R.id.stop);
        Stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                notPressed = false;
                stopEverything();
            }
        });

        final Button Toggle = findViewById(R.id.Toggle);
        Toggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ToggleSwitching();
            }
        });
    }

    public void ToggleSwitching() {
        System.out.println("Toggle Button Pressed");
        final Handler handler = new Handler();
        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                try {
                    //do your code here
                    if (notPressed) {
                        System.out.println("Turning off the lights");
                        GroupToggleSwitching(false, true, "c000");
                    } else {
                        System.out.println("Turning on the lights");
                        GroupToggleSwitching(true, true, "c000");
                    }
                } catch (Exception e) {
                    // TODO: handle exception
                    System.out.println("Printing Exception in toggling " + e);
                } finally {
                    //also call the same runnable to call it at regular interval
                    if (!PressedStop) {
                        handler.postDelayed(this, 2000);
                    } else {
                        GroupToggleSwitching(false, true, "c000");
                    }
                }
            }
        };
        //runnable must be execute once
        handler.post(runnable);
    }


    private void stopEverything() {
        PressedStop = true;
        //GroupToggleSwitching(false, true,"c000");
    }

    private void startNetwork() {
        Log.d("TAG_TEST", "Starting network");
        mNetwork = mobleNetwork.createNetwork(androidAddress);
        mNetwork.start(getApplicationContext());
        adviseCallbacks();
        scanQrCode();

    }

    private void scanQrCode() {
        qrScan.initiateScan();
    }

    //Getting the scan results
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if (result != null) {
            //if qrCode has nothing in it
            if (result.getContents() == null) {
                Toast.makeText(this, "Unsuccessful Attempt! Try again", Toast.LENGTH_LONG).show();
            } else {
                //if qr contains data
                try {
                    //converting the data to json
                    JSONObject obj = new JSONObject(result.getContents());
                    //substring if required for differentiating between plug and bulb
                    boolean status = callProvision(obj.getString("mac"));
                    if (status) {
                        Log.d("WAITING IN UI THREAD", "PROVISIONED SUCCESSFULLY");
                        //Toast.makeText(this,"Provisioned Successfully",Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    //that means the encoded format not matches in this case you can display whatever data is available on the qrCode to a toast
                    Toast.makeText(this, result.getContents(), Toast.LENGTH_LONG).show();
                }
            }
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }


    public boolean callProvision(String mac_address) {
        System.out.println("Under Development" + mac_address);
        provisioning_start_time = System.currentTimeMillis();
        is_group_test_running = false;
        Log.v(TAG_TEST, "inside callProvisionMethod");
        Log.v(TAG_TEST, "debugApp=>Node MO-BLE Address = > " + nodeAddress);
        mSettings = mNetwork.getSettings();

        if (mSettings != null) {

            DEVICE_ADDRESS = DEVICE_ADDRESS + 1;
            nodeAddress = mobleAddress.deviceAddress(DEVICE_ADDRESS);

            Log.i(TAG_TEST, "provisioning node address " + nodeAddress);
            Toast.makeText(MainActivity.this, "provisioning node address " + nodeAddress, Toast.LENGTH_SHORT).show();
            node_address_arr.add(nodeAddress);

            mProgress.show(MainActivity.this, "Adding Device . . . : ", true);

            CustomProvisioning mcp = new CustomProvisioning(false);

            return mSettings.provision(MainActivity.this, mac_address, nodeAddress, 10,
                    mProvisionCallback, mCapabilitiesListener,
                    mProvisionStateChanged, 10, mcp);

        } else {
            Log.v(TAG_TEST, "provision start failed");
            return false;
        }
    }

    mobleSettings.capabilitiesListener mCapabilitiesListener = new mobleSettings.capabilitiesListener() {
        @Override
        public void onCapabilitiesReceived(mobleSettings.Identifier identifier, Byte Element) {
            elementSize = Element;
            Log.v(TAG_TEST, "Inside capability listener " + identifier + " " + Element);
            Toast.makeText(MainActivity.this, "Inside capability Listener " + identifier + " " + Element, Toast.LENGTH_SHORT).show();
            identifier.setIdentified(true);
        }
    };

    public final mobleSettings.provisionerStateChanged mProvisionStateChanged =
            new mobleSettings.provisionerStateChanged() {
                @Override
                public void onStateChanged(final int state, final String label) {
                    Log.v(TAG_TEST, "Provisioning STATE ==> " + label + " : " + state);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            mProgress.setProgress(state + 1, "Adding Device . . . \n" + label + " " + state);
                        }
                    });
                }
            };

    public final mobleSettings.onProvisionComplete mProvisionCallback =
            new mobleSettings.onProvisionComplete() {
                @Override
                public void onCompleted(byte status) {
                    Log.v(TAG_TEST, "inside on complete method");
                    Toast.makeText(MainActivity.this, "inside on complete method", Toast.LENGTH_SHORT).show();
                    if (status == mobleProvisioningStatus.SUCCESS) {
                        Log.v(TAG_TEST, "Provisioning Completed Successfully");
                        Log.i(TAG_TEST, "adding node  " + nodeAddress + " to group = "
                                + mobleAddress.groupAddress(mobleAddress.GROUP_HEADER));

                        if (!is_group_test_running) {
                            Log.v(TAG_TEST, "Group test running");
                            mSettings.addGroup(MainActivity.this, nodeAddress, nodeAddress,
                                    mobleAddress.groupAddress(mobleAddress.GROUP_HEADER), mSubscriptionListener);
                            // progressDialog.setProgress(0);
                        }

                    } else {
                        System.out.println("Printing Callback Status " + status);
                        Log.v(TAG_TEST, "Provisioning Failed @70%");
                        mSettings.addLogl("Provisioning Failed @70%");
                    }
                }
            };


    final ConfigurationModelClient.ConfigModelSubscriptionStatusCallback mSubscriptionListener
            = new ConfigurationModelClient.ConfigModelSubscriptionStatusCallback() {
        @Override
        public void onModelSubscriptionStatus(boolean timeout, ApplicationParameters.Status status,
                                              ApplicationParameters.Address address,
                                              ApplicationParameters.Address subAddress,
                                              ApplicationParameters.GenericModelID model) {

            if (timeout) {
                mSettings.addGroup(
                        MainActivity.this,
                        nodeAddress,
                        nodeAddress, mobleAddress.groupAddress(mobleAddress.GROUP_HEADER),
                        mSubscriptionListener);

            } else {
                mProgress.hide();
                if (status == ApplicationParameters.Status.SUCCESS) {
                    Log.v(TAG_TEST, "Subscription Done Successfully");

                    mSettings.setPublicationAddress(MainActivity.this, nodeAddress,
                            nodeAddress, mobleAddress.GROUP_HEADER, mPublicationListener);
                } else {
                    Log.v(TAG_TEST, "Subscription Failed");
                }
            }
        }
    };

    final ConfigurationModelClient.ConfigModelPublicationStatusCallback mPublicationListener
            = new ConfigurationModelClient.ConfigModelPublicationStatusCallback() {

        @Override
        public void onModelPublicationStatus(boolean b, ApplicationParameters.Status status,
                                             ApplicationParameters.Address address,
                                             ApplicationParameters.Address address1,
                                             ApplicationParameters.KeyIndex keyIndex,
                                             ApplicationParameters.TTL ttl,
                                             ApplicationParameters.Time time,
                                             ApplicationParameters.GenericModelID genericModelID) {
            if (status == ApplicationParameters.Status.SUCCESS) {
                // publication_time = System.currentTimeMillis() - provisioning_complete_time;
                Log.d(TAG_TEST, "Publication Done Successfully");
                /*Toast.makeText(HomePageActivity.this,"Added to Default Group Successfully",
                        Toast.LENGTH_SHORT).show(); */
                GroupToggleSwitching(true, true, "c000");
            } else {
                Log.e(TAG_TEST, "Publication Failed");
            }
        }
    };

    public progress mProgress = new progress(MainActivity.this, new progress.onEventListener() {

        @Override
        public void onCancel() {
            mProgress.hide();
            try {
                mNetwork.advise(onNetworkStatusChanged);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        @Override
        public void onShow() {
        }

        @Override
        public void onHide() {
        }
    });

    public final defaultAppCallback onNetworkStatusChanged = new defaultAppCallback() {
        @Override
        public void inRange(boolean b, boolean b1) {
            super.inRange(b, b1);
            //System.out.println("Printing Network Values " + b + b1);
            onNetworkStatusChanged(b, b1);
        }
    };

    public void onNetworkStatusChanged(boolean prevStatus, boolean newStatus) {

        isNear = (prevStatus || newStatus) && (!prevStatus || newStatus);
    }

    public void GroupToggleSwitching(boolean onCommand, boolean rel_unRel, String address) {

    /*    mNetwork.getApplication().setRemoteData(nodeAddress,
                Nucleo.APPLI_CMD_LED_CONTROL,
                1, onCommand ? new byte[]{Nucleo.APPLI_CMD_LED_ON}
                        : new byte[]{Nucleo.APPLI_CMD_LED_OFF},rel_unRel); */
        /*network.getApplication().setRemoteData(addre, Nucleo.APPLI_CMD_LED_CONTROL, 1, isOnCommand ? new byte[]{Nucleo.APPLI_CMD_LED_ON} : new byte[]{Nucleo.APPLI_CMD_LED_OFF}, Utils.isReliableEnabled(context));
        System.out.println("Group Address Received is "+address); */

        if (onCommand) {
            Toast.makeText(this, "LED ON", Toast.LENGTH_SHORT).show();
            String on = "All ON";
            Status.setText(on);
            count++;
            String counting = "" + count;
            Count.setText(counting);
            notPressed = true;
            //Thread.sleep(5000);

        } else {
            Toast.makeText(this, "LED OFF", Toast.LENGTH_SHORT).show();
            String off = "All OFF";
            Status.setText(off);
            notPressed = false;
            if (rel_unRel && PressedStop)
                removeNodePopUp();
        }

        if (Utils.isVendorModelCommand(MainActivity.this))
        {
            rel_unRel = false;
            System.out.println("I am here in vendor model check");
            mNetwork.getApplication().setRemoteData(mobleAddress.BROADCAST, Nucleo.APPLI_CMD_LED_CONTROL, 1,
                    onCommand ? new byte[]{Nucleo.APPLI_CMD_LED_ON} : new byte[]{Nucleo.APPLI_CMD_LED_OFF},
                    rel_unRel);
        }
        else
        {
            ApplicationParameters.OnOff state = (onCommand ? ApplicationParameters.OnOff.ENABLED : ApplicationParameters.OnOff.DISABLED);

        ApplicationParameters.TID tid = new ApplicationParameters.TID(1);
        //ApplicationParameters.Time transitionTime = ApplicationParameters.Time.NONE;
        //ApplicationParameters.Delay del = new ApplicationParameters.Delay(20);

        //((MainActivity)getContext()).mUserDataRepository.getNewDataFromRemote("Generic OnOff command sent to ==>"+address, LoggerConstants.TYPE_SEND);
        mNetwork.getOnOffModel().setGenericOnOff(Utils.isReliableEnabled(getApplicationContext())
                , new ApplicationParameters.Address(Integer.parseInt(address, 16)),
                state,
                tid,
                null,
                null,
                Utils.isReliableEnabled(getApplicationContext()) ? Utils.mOnOffCallback : null);
    }

}
    private void removeNodePopUp() {
        AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
        builder1.setMessage("This action will un-provision the node from the network. Do you want to continue?");
        builder1.setCancelable(true);

        builder1.setPositiveButton("YES", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {

                if (/*!g_model*/false)
                {
                    mNetwork.getApplication().setRemoteData(nodeAddress, Nucleo.UNCONFIGURE, 1, new byte[]{}, false);

                }
                else
                    {
                    Log.d(TAG_TEST, "NODE un-provisioning from AddGroup _ 1 address " + nodeAddress);
                  //  loader.show();
                    //Utils.removeProvisionNodeFromJson(getActivity(), nodeSettings.getNodesUnicastAddress());
                        unAdviseCallbacks();

                    try {
                        mNetwork.getConfigurationModelClient().resetNode(new ApplicationParameters.Address(nodeAddress.mValue), mNodeResetCallback);
                        System.out.println("I am here"+nodeAddress.mValue);
                    }catch (Exception e){
                        e.printStackTrace();
                    }
                }

                //((UserApplication) getActivity().getApplication()).save();
                dialog.cancel();
            }
        });

        builder1.setNegativeButton("NO", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                dialog.cancel();
            }
        });

        AlertDialog alert11 = builder1.create();
        alert11.show();
    }

    public ConfigurationModelClient.NodeResetStatusCallback mNodeResetCallback = new ConfigurationModelClient.NodeResetStatusCallback() {
        @Override
        public void onNodeResetStatus(boolean TimeoutStatus) {
            System.out.println("Printing time out status from node reset callback"+TimeoutStatus);
            if (TimeoutStatus) {
                loader.hide();
                Log.v(TAG_TEST,"Node un-provisioned Failed");
                Toast.makeText(MainActivity.this, "Un-provisioned Failed",Toast.LENGTH_SHORT).show();
            } else {
                Log.v(TAG_TEST,"Node un-provisioned Successfully");
                Toast.makeText(MainActivity.this, "Un-provisioned Done",Toast.LENGTH_SHORT).show();
                adviseCallbacks();
                //clearUn_provisionList();
                //updateProvisionedTab();
                //updateModelTab();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {

                        mNetwork.stop();
                        loader.hide();
                        onDestroy();
                    }
                });

            }
        }
    };

    public void unAdviseCallbacks() {
        if (isAdvised) {
            isAdvised = false;
            try {
                Log.v(TAG_TEST,">> R S S I Call Stopped");
                //app.stop();

                mNetwork.unadvise(mOnDeviceAppearedCallback);
                mNetwork.unadvise(onNetworkStatusChanged);
                mNetwork.unadvise(onDeviceRssiChangedCallback);

                Log.v(TAG_TEST,"unadvised");
                //app.start();

            } catch (Exception e) {
                e.printStackTrace();
                System.out.println("Printing Exception");
            }
        }
    }

    public void adviseCallbacks() {
        Log.v(TAG_TEST,">> R S S I Call Resume");
        if (!isAdvised) {
            isAdvised = true;
            try {
                mNetwork.advise(mOnDeviceAppearedCallback);
                mNetwork.advise(mProxyConnectionEventCallback);
                mNetwork.advise(mOnDongleStateChanged);
                mNetwork.advise(onDeviceRssiChangedCallback);
                mNetwork.advise(onNetworkStatusChanged);
                if (true) {

                    mNetwork.advise(mWriteLocalCallback);
                    mNetwork.advise(modelCallback_cb);

                }
                //app.start();

            } catch (Exception e) {
                System.out.println("Advising Callbacks Exceptions "+e);
            }
        }
    }



    public defaultAppCallback mWriteLocalCallback = new defaultAppCallback() {
        @Override
        public void onWriteLocalData(mobleAddress peer, mobleAddress dst, Object cookies, short offset, byte count, byte[] data) {


            System.out.println(" VendorWrite Async CallBack source  : " + peer.toString());
            System.out.println(" VendorWrite Async CallBack destination  : " + dst.toString());
            System.out.println(" VendorWrite Async CallBack data : " + Utils.array2string(data));
            //mUserDataRepository.getNewDataFromRemote("Vendor Async CallBack source  ==>" + peer, LoggerConstants.TYPE_RECEIVE);
            //mUserDataRepository.getNewDataFromRemote("Vendor Async CallBack destination  ==>" + dst, LoggerConstants.TYPE_RECEIVE);
            //mUserDataRepository.getNewDataFromRemote("Vendor Async CallBack data ==>" + Utils.array2string(data), LoggerConstants.TYPE_RECEIVE);


        }
    };

    public defaultAppCallback modelCallback_cb = new defaultAppCallback() {
        @Override
        public void modelCallback(ApplicationParameters.Address src, ApplicationParameters.Address dst) {

            System.out.println(" GenericOnOff Async CallBack source : " + src);
            System.out.println(" GenericOnOff Async CallBack  dst : " + dst);

            //mUserDataRepository.getNewDataFromRemote("GenericOnOff Async CallBack source  ==>" + src, LoggerConstants.TYPE_RECEIVE);
            //mUserDataRepository.getNewDataFromRemote("GenericOnOff Async CallBack destination ==>" + dst, LoggerConstants.TYPE_RECEIVE);


        }
    };

    public final defaultAppCallback mOnDongleStateChanged = new defaultAppCallback() {
        @Override
        public void onDongleStateChanged(boolean enabled) {

            Toast.makeText(MainActivity.this, "Dongle State : " + enabled,Toast.LENGTH_SHORT).show();
            Log.v(TAG_TEST,"Dongle State : "+enabled);
        }
    };

    public final defaultAppCallback mProxyConnectionEventCallback = new defaultAppCallback() {

        @Override
        public void onProxyConnectionEvent(boolean process, String proxyAddress) {

            if (proxyAddress != null) {
                System.out.println("Proxy Mac = " + proxyAddress);

                isNear = true;
                Utils.setProxyNode(MainActivity.this, proxyAddress);
                //mLostConnectionDialog.hideDialog();

                //update ui for proxy node
                //fragmentCommunication(new ProvisionedTabFragment().getClass().getName(), null, 0, null, false, null);


            } else {
                isNear = false;
                /*if (mLostConnectionDialog.mDialog != null) {
                    if (!mLostConnectionDialog.mDialog.isShowing()) {
                        mLostConnectionDialog.createDialog();
                    }
                } */
            }
        }
    };

    public defaultAppCallback mOnDeviceAppearedCallback = new defaultAppCallback() {
        @Override
        public void onDeviceAppeared(String bt_address) {

            Log.v(TAG_TEST,">>>>>>>>>>>>>>>>>>>>> DEVICE APPEARED : >>>>>>>>> " + bt_address);
            //onScanningDevice(bt_address);
            //onNewDeviceAppeared(bt_address);
        }
    };

    public defaultAppCallback onDeviceRssiChangedCallback = new defaultAppCallback() {

        @Override
        public void onDeviceRssiChanged(final String bt_address, final int mRssi) {
            super.onDeviceRssiChanged(bt_address, mRssi);

           // System.out.println(">> R S S I Call Continue . . . ");
            //onScanningDevice(bt_address);
            if(startRSSIUpdate)
            {
                if(bt_address != null && !bt_address.isEmpty())
                {
                    onScanningDevice(bt_address);
                    new Handler().post(new Runnable() {
                        @Override
                        public void run() {

                            System.out.println("I have called Scanning Device");
                        }
                    });
                }
            }

        }
    };

    public void onScanningDevice(String bt_address)
    {
        Device device = null;
        try {
            try {
                Future<DeviceCollection> futureED = mNetwork.enumerateDevices();

                try {
                    DeviceCollection collectionD = futureED.get();
                    device = collectionD.getDevice(bt_address);

                } catch (InterruptedException e) {
                    System.out.println("Interrupted exception");

                } catch (ExecutionException e) {
                    System.out.println("Execution exception");
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        if(device != null)
        {
            System.out.println("printing device"+device);
        }

    }

    @Override
    public void onBackPressed(){
        super.onBackPressed();
    }

    @Override
    public void onResume(){
        super.onResume();
    }

    @Override
    public void onDestroy(){
        super.onDestroy();
    }
}
