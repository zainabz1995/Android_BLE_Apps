package com.example.grouptoggletestingapp;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;

import com.msi.moble.ApplicationParameters;
import com.msi.moble.GenericOnOffModelClient;

class Utils {
    @SuppressLint("StaticFieldLeak")
    static Context contextMainActivity;

    static void setVendorModelCommand(Context context, boolean setReliable) {
        if (context == null)
            return;
        AppSharedPrefs sp = AppSharedPrefs.getInstance(context);
        sp.put(context.getString(R.string.key_isVendorModelCommand), setReliable);
    }

    static boolean isVendorModelCommand(Context context) {
        if (context == null)
            return false;
        try {
            AppSharedPrefs sp = AppSharedPrefs.getInstance(context);
            //return (boolean) sp.get(context.getString(R.string.key_isVendorModelCommand));
            Object obj = sp.get(context.getString(R.string.key_isVendorModelCommand));
            System.out.println("Printing inside isVendorModelCommand "+obj);
            if (obj != null) {
                //return (boolean) sp.get(context.getString(R.string.key_isVendorModelCommand));
                return (boolean) obj;
            }
        } catch (NullPointerException e) {
            e.printStackTrace();
        }
        return false;
    }


    static String generateMeshUUID(String networkKey) {
        if (networkKey == null)
            return null;

        StringBuilder strBuilderUUID = new StringBuilder();
        StringBuilder strBuilder = new StringBuilder();
        strBuilder.append(networkKey);
        strBuilder = strBuilder.reverse();

        //for (int i = strArray.length-1; i>=0; i--)

        char[] strArray = String.valueOf(strBuilder).toCharArray();
        for (int i = 0; i < strArray.length; i++) {
            if (i == 8 || i == 12 || i == 16 || i == 20) {
                strBuilderUUID.append("-");
            }
            strBuilderUUID.append(strArray[i]);
        }
        return String.valueOf(strBuilderUUID);
    }

    static String array2string(byte[] data) {
        char[] hex = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};
        StringBuilder buffer = new StringBuilder();
        if (data != null) {
            for (byte datum : data) {
                buffer.append(hex[(datum >> 4) & 0x0F]);
                buffer.append(hex[(datum) & 0x0F]);
            }
        }
        return buffer.toString();
    }

    static boolean isReliableEnabled(Context context) {
        if (context == null) {
            System.out.println("Reliable is not enabled");
            return false;
        }
        try {
            AppSharedPrefs sp = AppSharedPrefs.getInstance(context);
            Object obj = sp.get(context.getString(R.string.key_isReliable));
            if(obj != null)
            {
                return (boolean) sp.get(context.getString(R.string.key_isReliable));
            }
            System.out.println("Reliable is enabled");

        } catch (NullPointerException e) {
            e.printStackTrace();
        }

        return false;
    }

    static void hideKeyboard(Context context, View view) {
        if (context == null || view == null) {
            return;
        }
        try {
            InputMethodManager inputManager = (InputMethodManager) context.getSystemService(Activity.INPUT_METHOD_SERVICE);
            assert inputManager != null;
            inputManager.hideSoftInputFromWindow(view.getWindowToken(), 0);
        } catch (Exception e) {
            Log.d(" ","Error in hideKeyboard() : " + e.toString());
        }

    }

    static GenericOnOffModelClient.GenericOnOffStatusCallback mOnOffCallback = new GenericOnOffModelClient.GenericOnOffStatusCallback() {
        @Override
        public void onOnOffStatus(boolean b, ApplicationParameters.OnOff onOff, ApplicationParameters.OnOff onOff1, ApplicationParameters.Time time, ApplicationParameters.Address address) {
            Log.d("I m here","in Generic onOFF callback");
        }
    };

    static void setProxyNode(Context context, String proxyAddress) {

        if (context == null)
            return;
        AppSharedPrefs sp = AppSharedPrefs.getInstance(context);
        sp.put(context.getString(R.string.proxy_address), proxyAddress);

    }

    }
